# Screenshot Studio · 留白

通用截图拼接与视觉排版工具。纯前端，单文件，无需服务器。

## 使用

直接打开 `index.html` 即可。所有模板已内嵌，不请求任何外部资源。

## 部署

本仓库启用 GitHub Pages 后，访问 `https://<你的用户名>.github.io/<仓库名>/` 即可。
